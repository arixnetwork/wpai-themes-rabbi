<?php
/**
 * WPAi Themes of Rabbi - AI-Enhanced Features
 */

if (!defined('ABSPATH')) exit;

class WPAI_Rabbi_AI_Features {
    
    public function init() {
        add_action('wp_footer', [$this, 'ai_search_modal']);
        add_filter('excerpt_length', [$this, 'ai_optimized_excerpt_length']);
    }
    
    public function ai_search_modal() {
        if (!is_search()) : ?>
        <dialog id="ai-search-modal" class="ai-search-modal">
            <h3>🤖 AI Smart Search</h3>
            <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <input type="search" name="s" placeholder="Ask naturally..." class="ai-search-input">
                <button type="submit">Search</button>
            </form>
        </dialog>
        <?php endif;
    }
    
    public function ai_optimized_excerpt_length($length) {
        return is_search() || is_archive() ? 24 : $length;
    }
}
