<?php
/**
 * WPAi Themes of Rabbi - SEO Core Foundation
 */

if (!defined('ABSPATH')) exit;

class WPAI_Rabbi_SEO_Core {
    
    public function init() {
        add_action('wp_head', [$this, 'add_meta_tags'], 1);
        add_filter('wp_title', [$this, 'optimize_title'], 10, 2);
    }
    
    public function add_meta_tags() {
        if (is_singular()) {
            echo '<meta name="description" content="' . esc_attr(get_the_excerpt()) . '">' . "\n";
        }
    }
    
    public function optimize_title($title, $sep) {
        if (is_feed()) return $title;
        global $page, $paged;
        $title .= get_bloginfo('name', 'display');
        if ($paged >= 2 || $page >= 2) {
            $title .= " $sep " . sprintf(__('Page %s', 'wpai-rabbi'), max($paged, $page));
        }
        return $title;
    }
}
