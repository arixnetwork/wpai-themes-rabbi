<?php
/**
 * WPAi Themes of Rabbi - Functions & Definitions
 */

if (!defined('ABSPATH')) exit;

define('WPAI_RABBI_VERSION', '1.0.0');
define('WPAI_RABBI_DIR', get_template_directory());
define('WPAI_RABBI_URI', get_template_directory_uri());

// Load theme text domain
add_action('after_setup_theme', function() {
    load_theme_textdomain('wpai-rabbi', WPAI_RABBI_DIR . '/languages');
    
    // Add theme support
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
    add_theme_support('custom-logo');
    add_theme_support('align-wide');
    add_theme_support('responsive-embeds');
    
    // Register navigation menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'wpai-rabbi'),
        'footer'  => __('Footer Menu', 'wpai-rabbi'),
    ]);
    
    // Set content width
    if (!isset($content_width)) $content_width = 1200;
});

// Enqueue scripts and styles
add_action('wp_enqueue_scripts', function() {
    // Critical CSS inlined in header
    wp_enqueue_style(
        'wpai-rabbi-style',
        get_stylesheet_uri(),
        [],
        WPAI_RABBI_VERSION
    );
    
    // Main CSS deferred
    wp_enqueue_style(
        'wpai-rabbi-main',
        WPAI_RABBI_URI . '/assets/css/main.css',
        [],
        WPAI_RABBI_VERSION,
        ['media' => 'print', 'onload' => "this.media='all'"]
    );
    
    // AI UI JavaScript
    wp_enqueue_script(
        'wpai-ai-ui',
        WPAI_RABBI_URI . '/assets/js/ai-ui.js',
        [],
        WPAI_RABBI_VERSION,
        ['strategy' => 'defer']
    );
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}, 5);

// Load admin dashboard
if (is_admin()) {
    require_once WPAI_RABBI_DIR . '/inc/class-admin-dashboard.php';
}

// Load performance optimizer
require_once WPAI_RABBI_DIR . '/inc/class-performance.php';

// Load AI features
require_once WPAI_RABBI_DIR . '/inc/class-ai-features.php';

// Load SEO core
require_once WPAI_RABBI_DIR . '/inc/class-seo-core.php';

// Load template tags
require_once WPAI_RABBI_DIR . '/inc/template-tags.php';

// Initialize classes
add_action('init', function() {
    if (class_exists('WPAI_Rabbi_Performance')) {
        (new WPAI_Rabbi_Performance())->init();
    }
    if (class_exists('WPAI_Rabbi_AI_Features')) {
        (new WPAI_Rabbi_AI_Features())->init();
    }
    if (class_exists('WPAI_Rabbi_SEO_Core')) {
        (new WPAI_Rabbi_SEO_Core())->init();
    }
});
