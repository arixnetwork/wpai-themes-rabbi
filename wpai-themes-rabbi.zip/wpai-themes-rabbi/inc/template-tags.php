<?php
/**
 * WPAi Themes of Rabbi - Template Tags
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('wpai_rabbi_posted_on')) {
    function wpai_rabbi_posted_on() {
        $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
        $time_string = sprintf($time_string,
            esc_attr(get_the_date(DATE_W3C)),
            esc_html(get_the_date())
        );
        echo '<span class="posted-on">' . $time_string . '</span>';
    }
}

if (!function_exists('wpai_rabbi_posted_by')) {
    function wpai_rabbi_posted_by() {
        echo '<span class="byline"><span class="author vcard"><a class="url fn n" href="' . 
             esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . 
             esc_html(get_the_author()) . '</a></span></span>';
    }
}
