<?php
/**
 * WPAi Themes of Rabbi - Footer Template
 */

if (!defined('ABSPATH')) exit;
?>

<footer class="site-footer" id="colophon">
    <div class="container">
        <div class="site-info">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. 
            Powered by <a href="https://wordpress.org">WordPress</a> & 
            <a href="https://wpairabbi.com">WPAi Rabbi Theme</a>.</p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
