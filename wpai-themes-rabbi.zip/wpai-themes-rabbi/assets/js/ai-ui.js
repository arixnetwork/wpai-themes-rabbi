/**
 * WPAi Themes of Rabbi - AI UI Interactions
 */

document.addEventListener('DOMContentLoaded', function() {
    // Dark mode toggle
    const darkModeQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    function applyDarkMode(isDark) {
        document.documentElement.style.setProperty('--color-bg', isDark ? '#0f172a' : '#ffffff');
        document.documentElement.style.setProperty('--color-text', isDark ? '#f1f5f9' : '#1e293b');
    }
    
    applyDarkMode(darkModeQuery.matches);
    darkModeQuery.addEventListener('change', (e) => applyDarkMode(e.matches));
    
    // Smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
    
    // Lazy load images (progressive enhancement)
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                        imageObserver.unobserve(img);
                    }
                }
            });
        });
        
        document.querySelectorAll('img[data-src]').forEach(img => imageObserver.observe(img));
    }
    
    console.log('🤖 WPAi Rabbi Theme loaded successfully!');
});
