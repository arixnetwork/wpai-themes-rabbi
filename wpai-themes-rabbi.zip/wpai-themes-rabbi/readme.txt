=== WPAi Themes of Rabbi ===
Contributors: rabbi-dev
Tags: accessibility-ready, block-patterns, custom-colors, custom-menu, editor-style, featured-images, full-site-editing, one-column, rtl-language-support, theme-options, translation-ready, two-columns
Requires at least: 6.4
Tested up to: 6.5
Requires PHP: 8.2
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Ultra-fast, AI-inspired WordPress theme with native Rank Math SEO integration.

== Description ==

WPAi Themes of Rabbi is a modern, performance-focused WordPress theme designed for speed, SEO excellence, and beautiful AI-inspired user experiences.

== Features ==

* Core Web Vitals optimized (LCP <1.2s, CLS <0.1)
* Native Rank Math SEO compatibility
* Block theme (FSE) support
* Dark/light mode auto-detection
* AI-powered smart search
* Semantic HTML5 structure
* Accessibility-ready (WCAG 2.1 AA)
* Mobile-first responsive design

== Installation ==

1. Upload the theme folder to `/wp-content/themes/`
2. Activate the theme via WordPress Admin > Appearance > Themes
3. Install Rank Math plugin for full SEO features
4. Configure theme settings under Appearance > WPAi Rabbi

== Changelog ==

= 1.0.0 =
* Initial release

== Resources ==

* Uses System UI font stack
* Rank Math SEO integration
* WordPress Block Editor support
