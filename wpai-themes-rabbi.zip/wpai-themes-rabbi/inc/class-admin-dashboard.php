<?php
/**
 * WPAi Themes of Rabbi - Admin Dashboard
 */

if (!defined('ABSPATH')) exit;

class WPAI_Rabbi_Admin {
    
    private $option_group = 'wpai_rabbi_options';
    private $option_name  = 'wpai_rabbi_settings';
    
    public function init() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
    }
    
    public function add_admin_menu() {
        add_theme_page(
            __('WPAi Rabbi Settings', 'wpai-rabbi'),
            __('🤖 WPAi Rabbi', 'wpai-rabbi'),
            'manage_options',
            'wpai-rabbi-settings',
            [$this, 'render_settings_page']
        );
    }
    
    public function register_settings() {
        register_setting($this->option_group, $this->option_name, [
            'sanitize_callback' => [$this, 'sanitize_settings'],
            'default' => $this->get_default_settings()
        ]);
        
        add_settings_section('wpai_rabbi_performance', __('⚡ Performance', 'wpai-rabbi'),
            [$this, 'render_performance_section'], 'wpai-rabbi-settings');
        
        add_settings_field('enable_critical_css', __('Critical CSS', 'wpai-rabbi'),
            [$this, 'render_checkbox'], 'wpai-rabbi-settings', 'wpai_rabbi_performance',
            ['label' => __('Inline above-the-fold CSS', 'wpai-rabbi'), 'option' => 'enable_critical_css']);
        
        add_settings_field('enable_dark_mode', __('Dark Mode', 'wpai-rabbi'),
            [$this, 'render_checkbox'], 'wpai-rabbi-settings', 'wpai_rabbi_performance',
            ['label' => __('Auto dark mode', 'wpai-rabbi'), 'option' => 'enable_dark_mode']);
    }
    
    public function render_settings_page() {
        ?>
        <div class="wrap wpai-rabbi-admin">
            <h1>🤖 WPAi Themes of Rabbi <small>v<?php echo wp_get_theme()->get('Version'); ?></small></h1>
            <p>Ultra-fast, AI-inspired WordPress theme</p>
            
            <div class="wpai-card">
                <?php settings_fields($this->option_group); ?>
                <?php do_settings_sections('wpai-rabbi-settings'); ?>
                <?php submit_button(__('Save Settings', 'wpai-rabbi')); ?>
            </div>
        </div>
        <?php
    }
    
    public function render_checkbox($args) {
        $options = get_option($this->option_name, $this->get_default_settings());
        $value = $options[$args['option']] ?? false;
        printf('<label><input type="checkbox" name="%s[%s]" value="1" %s> %s</label>',
            esc_attr($this->option_name), esc_attr($args['option']),
            checked($value, 1, false), esc_html($args['label']));
    }
    
    public function render_performance_section() {
        echo '<p>Optimize for Core Web Vitals.</p>';
    }
    
    public function sanitize_settings($input) {
        $sanitized = [];
        $sanitized['enable_critical_css'] = isset($input['enable_critical_css']) ? 1 : 0;
        $sanitized['enable_dark_mode'] = isset($input['enable_dark_mode']) ? 1 : 0;
        return $sanitized;
    }
    
    private function get_default_settings() {
        return ['enable_critical_css' => 1, 'enable_dark_mode' => 1];
    }
    
    public function enqueue_admin_assets($hook) {
        if ('appearance_page_wpai-rabbi-settings' !== $hook) return;
        wp_enqueue_style('wp-color-picker');
    }
}

if (is_admin()) {
    add_action('init', function() {
        if (class_exists('WPAI_Rabbi_Admin')) {
            (new WPAI_Rabbi_Admin())->init();
        }
    });
}
