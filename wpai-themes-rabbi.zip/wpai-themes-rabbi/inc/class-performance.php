<?php
/**
 * WPAi Themes of Rabbi - Performance Optimization Core
 */

if (!defined('ABSPATH')) exit;

class WPAI_Rabbi_Performance {
    
    public function init() {
        add_action('wp_enqueue_scripts', [$this, 'optimize_assets'], 5);
        add_filter('script_loader_tag', [$this, 'async_defer_scripts'], 10, 3);
        add_filter('wp_resource_hints', [$this, 'add_preconnect'], 10, 2);
        add_action('template_redirect', [$this, 'lcp_image_optimization']);
    }
    
    public function optimize_assets() {
        // Remove emojis if not needed
        if (!has_block('core/quote') && !has_block('core/pullquote')) {
            remove_action('wp_head', 'print_emoji_detection_script', 7);
            remove_action('wp_print_styles', 'print_emoji_styles');
        }
    }
    
    public function async_defer_scripts($tag, $handle, $src) {
        $defer_handles = ['wpai-ai-ui', 'rank-math-frontend'];
        if (in_array($handle, $defer_handles)) {
            return str_replace(' src', ' defer src', $tag);
        }
        return $tag;
    }
    
    public function add_preconnect($urls, $relation_type) {
        if ('preconnect' === $relation_type) {
            $urls[] = ['href' => 'https://fonts.googleapis.com', 'crossorigin' => 'anonymous'];
        }
        return $urls;
    }
    
    public function lcp_image_optimization() {
        if (is_singular() && has_post_thumbnail()) {
            $image_id = get_post_thumbnail_id();
            $image_url = wp_get_attachment_image_url($image_id, 'large');
            if ($image_url) {
                echo '<link rel="preload" as="image" href="' . esc_url($image_url) . '" fetchpriority="high">' . "\n";
            }
        }
    }
}
