<?php
/**
 * WPAi Themes of Rabbi - Rank Math Native Compatibility
 */

if (!defined('ABSPATH')) exit;

// Register theme support for Rank Math breadcrumbs
add_theme_support('rank-math-breadcrumbs');

// Set optimal defaults for General Settings
add_filter('rank_math/settings/defaults/general', function($settings) {
    return array_merge($settings, [
        'strip_category_base'     => 'on',
        'nofollow_external_links' => 'on',
        'redirect_attachments'    => 'on',
        'clean_campaign_tracking' => 'on',
    ]);
});

// Preconfigure SEO Titles & Meta
add_filter('rank_math/settings/defaults/titles', function($settings) {
    $settings['capitalize_titles'] = 'on';
    $settings['noindex_empty_taxonomies'] = 'on';
    $settings['pt_post_title'] = '%title% %sep% %sitename%';
    $settings['pt_post_description'] = '%excerpt%';
    $settings['pt_post_robots'] = ['index', 'follow'];
    return $settings;
});

// Optimize sitemap settings
add_filter('rank_math/settings/defaults/sitemap', function($settings) {
    return array_merge($settings, [
        'items_per_page' => '200',
        'include_images' => 'off',
        'ping_search_engines' => 'on',
    ]);
});

// Add AI-specific schema defaults
add_filter('rank_math/settings/snippet/type', function($type, $post_type) {
    if ('ai_tool' === $post_type) {
        return 'software';
    }
    return $type;
}, 10, 2);

// Register custom variables for AI metadata
add_action('rank_math/vars/register_extra_replacements', function() {
    rank_math_register_var_replacement(
        'ai_confidence_score',
        [
            'name'        => __('AI Confidence Score', 'wpai-rabbi'),
            'description' => __('AI-generated content confidence rating', 'wpai-rabbi'),
            'variable'    => 'ai_confidence_score',
            'example'     => '94%',
        ],
        'wpai_rabbi_get_ai_score'
    );
});

if (!function_exists('wpai_rabbi_get_ai_score')) {
    function wpai_rabbi_get_ai_score() {
        $score = get_post_meta(get_the_ID(), '_ai_confidence', true);
        return $score ? $score . '%' : 'N/A';
    }
}

// Optimize breadcrumb output
add_filter('rank_math/frontend/breadcrumb/args', function($args) {
    return array_merge($args, [
        'wrap_before' => '<nav class="breadcrumb" aria-label="Breadcrumb"><ol class="breadcrumb-list">',
        'wrap_after'  => '</ol></nav>',
        'delimiter'   => '<li class="breadcrumb-separator" aria-hidden="true">/</li>',
    ]);
});

// Enhance OpenGraph for social sharing
add_filter('rank_math/opengraph/facebook/og_title', function($content) {
    if (is_singular('post')) {
        $ai_prefix = get_post_meta(get_the_ID(), '_ai_generated', true) ? '🤖 ' : '';
        return $ai_prefix . $content;
    }
    return $content;
});
